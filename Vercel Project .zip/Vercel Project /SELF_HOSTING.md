# TokIntel self-hosting package

This version is ready to upload to a Python host, VPS, Docker host, or Vercel as a demo. For durable production records, use a host with persistent storage or connect a managed database.

## Initial admin login

- Admin page: `/admin`
- Email: `admin@tokintel.local`
- Password: `T0kIntel-QP3npKVUH2iXekvE`

Change these values in `.env` before production if you want different credentials.

## Admin audit page

The admin page lists registered emails and whether each has an encrypted Apify token configured. It also logs the email account that searched each TikTok username, the provider (`Apify`), the actor/API (`clockworks/tiktok-profile-scraper`), result status, and timestamp. It never displays the actual API token.

## Run directly

```bash
cp .env.example .env
# Set FLASK_SECRET_KEY and APP_ENCRYPTION_KEY in .env
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
gunicorn --bind 0.0.0.0:5000 --workers 2 app:app
```

Set `APP_ENCRYPTION_KEY` to a Fernet key, for example:

```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

## Docker

```bash
docker build -t tokintel .
docker run -d --name tokintel -p 5000:5000 --env-file .env -v "$PWD/data:/app/data" -v "$PWD/reports:/app/reports" tokintel
```

The `data/` volume keeps accounts and encrypted tokens across restarts. Keep `.env` private and back up `data/` securely.

## Google sign-in

Email/password works immediately. To enable Google sign-in, add `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` to `.env`, then register this callback URL with Google:

```text
https://YOUR-DOMAIN/login/google/callback
```

## Security notes

- API tokens are encrypted at rest with `APP_ENCRYPTION_KEY` and associated with the signed-in user ID.
- Tokens are never included in HTML, URLs, reports, admin pages, or logs.
- Use HTTPS in production and set a strong `FLASK_SECRET_KEY`.
- This tool is for lawful, authorized research only.
