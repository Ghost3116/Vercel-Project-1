import base64
import hashlib
import json
import os
import re
import secrets
import sqlite3
from datetime import UTC, datetime
from functools import wraps
from pathlib import Path

from apify_client import ApifyClient
from cryptography.fernet import Fernet, InvalidToken
from dotenv import load_dotenv
from flask import Flask, flash, jsonify, redirect, render_template, request, send_file, session, url_for
from authlib.integrations.flask_client import OAuth
from werkzeug.security import check_password_hash, generate_password_hash

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
REPORTS_DIR = BASE_DIR / "reports"
DATA_DIR.mkdir(exist_ok=True)
REPORTS_DIR.mkdir(exist_ok=True)
DB_PATH = Path(os.getenv("DATABASE_PATH", DATA_DIR / "tokintel.sqlite3"))
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", secrets.token_hex(32))
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax", MAX_CONTENT_LENGTH=512 * 1024)
oauth = OAuth(app)
GOOGLE_ENABLED = bool(os.getenv("GOOGLE_CLIENT_ID") and os.getenv("GOOGLE_CLIENT_SECRET"))
if GOOGLE_ENABLED:
    oauth.register(name="google", client_id=os.getenv("GOOGLE_CLIENT_ID"), client_secret=os.getenv("GOOGLE_CLIENT_SECRET"), server_metadata_url="https://accounts.google.com/.well-known/openid-configuration", client_kwargs={"scope": "openid email profile"})
USERNAME_RE = re.compile(r"^[A-Za-z0-9._-]{1,50}$")
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@tokintel.local").strip().lower()
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "T0kIntel-QP3npKVUH2iXekvE")


def get_fernet():
    key = os.getenv("APP_ENCRYPTION_KEY")
    if not key:
        # Dev fallback only; production must set APP_ENCRYPTION_KEY so tokens survive restarts.
        key = base64.urlsafe_b64encode(hashlib.sha256(app.secret_key.encode()).digest()).decode()
    return Fernet(key.encode())


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT,
          google_sub TEXT UNIQUE, is_admin INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS api_tokens (
          user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
          encrypted_token TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS reports (
          id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          filename TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS searches (
          id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          target TEXT NOT NULL, status TEXT NOT NULL, provider TEXT NOT NULL,
          actor TEXT NOT NULL, created_at TEXT NOT NULL
        );
        """)
        admin = conn.execute("SELECT id FROM users WHERE email=?", (ADMIN_EMAIL,)).fetchone()
        if not admin:
            conn.execute("INSERT INTO users(email,password_hash,is_admin,created_at) VALUES(?,?,1,?)", (ADMIN_EMAIL, generate_password_hash(ADMIN_PASSWORD), datetime.now(UTC).isoformat()))


def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    with db() as conn:
        return conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()


def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not current_user():
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapped


def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user:
            return redirect(url_for("login", next=request.path))
        if not user["is_admin"]:
            return "Forbidden", 403
        return fn(*args, **kwargs)
    return wrapped


def clean_username(value):
    return str(value).strip().lstrip("@").strip()


def encrypt_token(token):
    return get_fernet().encrypt(token.encode()).decode()


def decrypt_token(value):
    try:
        return get_fernet().decrypt(value.encode()).decode()
    except InvalidToken:
        return None


def get_user_token(user_id):
    with db() as conn:
        row = conn.execute("SELECT encrypted_token FROM api_tokens WHERE user_id=?", (user_id,)).fetchone()
    return decrypt_token(row["encrypted_token"]) if row else None


def extract_profile(item):
    author = item.get("authorMeta") or {}
    return {"username": author.get("name"), "full_name": author.get("nickName"), "profile_url": author.get("profileUrl"), "avatar_url": author.get("avatar"), "verified": author.get("verified"), "signature": author.get("signature"), "bio_link": author.get("bioLink"), "private_account": author.get("privateAccount"), "followers": author.get("fans"), "following": author.get("following"), "friends": author.get("friends"), "likes": author.get("heart"), "videos": author.get("video"), "create_time": author.get("createTime")}


def lookup(username, token):
    client = ApifyClient(token)
    run = client.actor("clockworks/tiktok-profile-scraper").call(run_input={"profiles": [username], "profileScrapeSections": ["videos"], "profileSorting": "latest", "resultsPerPage": 1, "shouldDownloadVideos": False, "shouldDownloadCovers": False, "shouldDownloadAvatars": False})
    items = list(client.dataset(run.default_dataset_id).iterate_items())
    return extract_profile(items[0]) if items else {}


def api_error(exc):
    text = str(exc).strip()
    if "401" in text or "403" in text or "Unauthorized" in text:
        return "Apify rejected this token. Check that it is valid and has scraper access."
    return text or "The lookup failed. Please try again."


@app.before_request
def startup():
    init_db()


@app.context_processor
def inject_user():
    return {"user": current_user()}


@app.get("/")
def index():
    return render_template("index.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with db() as conn:
            user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and user["password_hash"] and check_password_hash(user["password_hash"], password):
            session.clear(); session["user_id"] = user["id"]
            return redirect(request.args.get("next") or url_for("index"))
        flash("Invalid email or password.", "error")
    return render_template("auth.html", mode="login", google_enabled=GOOGLE_ENABLED)


@app.get("/login/google")
def google_login():
    if not GOOGLE_ENABLED:
        flash("Google sign-in is not configured on this server yet.", "error")
        return redirect(url_for("login"))
    return oauth.google.authorize_redirect(url_for("google_callback", _external=True))


@app.get("/login/google/callback")
def google_callback():
    if not GOOGLE_ENABLED:
        return redirect(url_for("login"))
    try:
        token = oauth.google.authorize_access_token()
        profile = token.get("userinfo") or oauth.google.userinfo()
        email = str(profile.get("email", "")).strip().lower()
        google_sub = str(profile.get("sub", ""))
        if not email or not google_sub:
            raise ValueError("Google did not return a verified email.")
        with db() as conn:
            user = conn.execute("SELECT * FROM users WHERE email=? OR google_sub=?", (email, google_sub)).fetchone()
            if user:
                conn.execute("UPDATE users SET google_sub=? WHERE id=?", (google_sub, user["id"]))
                uid = user["id"]
            else:
                uid = conn.execute("INSERT INTO users(email,google_sub,created_at) VALUES(?,?,?)", (email, google_sub, datetime.now(UTC).isoformat())).lastrowid
        session.clear(); session["user_id"] = uid
        return redirect(url_for("index"))
    except Exception:
        flash("Google sign-in failed. Please try email and password or try again.", "error")
        return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower(); password = request.form.get("password", "")
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email) or len(password) < 8:
            flash("Use a valid email and a password of at least 8 characters.", "error")
        else:
            try:
                with db() as conn:
                    conn.execute("INSERT INTO users(email,password_hash,created_at) VALUES(?,?,?)", (email, generate_password_hash(password), datetime.now(UTC).isoformat()))
                flash("Account created. Please sign in.", "success"); return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("That email is already registered.", "error")
    return render_template("auth.html", mode="register", google_enabled=GOOGLE_ENABLED)


@app.get("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))


@app.get("/api/status")
@login_required
def status():
    return jsonify({"configured": bool(get_user_token(session["user_id"]))})


@app.post("/api/key")
@login_required
def save_key():
    token = str((request.get_json(silent=True) or {}).get("token", "")).strip()
    if len(token) < 10 or any(ch.isspace() for ch in token):
        return jsonify({"error": "Enter a valid Apify API token."}), 400
    with db() as conn:
        conn.execute("INSERT INTO api_tokens(user_id,encrypted_token,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET encrypted_token=excluded.encrypted_token,updated_at=excluded.updated_at", (session["user_id"], encrypt_token(token), datetime.now(UTC).isoformat()))
    return jsonify({"ok": True})


@app.delete("/api/key")
@login_required
def clear_key():
    with db() as conn: conn.execute("DELETE FROM api_tokens WHERE user_id=?", (session["user_id"],))
    return jsonify({"ok": True})


@app.post("/api/scan")
@login_required
def scan():
    token = get_user_token(session["user_id"])
    if not token: return jsonify({"error": "Add your Apify API token before scanning."}), 401
    raw = (request.get_json(silent=True) or {}).get("usernames", "")
    candidates = raw if isinstance(raw, list) else str(raw).splitlines()
    targets = list(dict.fromkeys(clean_username(x) for x in candidates if clean_username(x)))
    if not targets: return jsonify({"error": "Enter at least one TikTok username."}), 400
    if len(targets) > 25: return jsonify({"error": "Please scan at most 25 usernames per batch."}), 400
    bad = next((x for x in targets if not USERNAME_RE.fullmatch(x)), None)
    if bad: return jsonify({"error": f"Invalid username: @{bad}"}), 400
    results = []
    for target in targets:
        try:
            profile = lookup(target, token); status = "hit" if profile else "miss"; results.append({"target": target, "status": status, "profile": profile})
        except Exception as exc:
            status = "error"; results.append({"target": target, "status": status, "error": api_error(exc)})
        with db() as conn:
            conn.execute("INSERT INTO searches(user_id,target,status,provider,actor,created_at) VALUES(?,?,?,?,?,?)", (session["user_id"], target, status, "Apify", "clockworks/tiktok-profile-scraper", datetime.now(UTC).isoformat()))
    report = {"generated_at": datetime.now(UTC).isoformat(), "user_email": current_user()["email"], "summary": {"total": len(results), "hits": sum(r["status"] == "hit" for r in results), "misses": sum(r["status"] == "miss" for r in results), "errors": sum(r["status"] == "error" for r in results)}, "results": results}
    filename = f"tokintel_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{secrets.token_hex(3)}.json"
    (REPORTS_DIR / filename).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    with db() as conn: conn.execute("INSERT INTO reports(user_id,filename,created_at) VALUES(?,?,?)", (session["user_id"], filename, datetime.now(UTC).isoformat()))
    return jsonify({"report": report, "download": url_for("download_report", filename=filename)})


@app.get("/reports/<path:filename>")
@login_required
def download_report(filename):
    with db() as conn: row = conn.execute("SELECT id FROM reports WHERE filename=? AND user_id=?", (filename, session["user_id"])).fetchone()
    path = (REPORTS_DIR / filename).resolve()
    if not row or path.parent != REPORTS_DIR.resolve() or path.suffix != ".json" or not path.is_file(): return "Report not found", 404
    return send_file(path, as_attachment=True, download_name=path.name, mimetype="application/json")


@app.get("/admin")
@admin_required
def admin():
    with db() as conn:
        users = conn.execute("SELECT u.email,u.created_at,u.is_admin,CASE WHEN a.user_id IS NULL THEN 0 ELSE 1 END AS has_token FROM users u LEFT JOIN api_tokens a ON a.user_id=u.id ORDER BY u.created_at DESC").fetchall()
        searches = conn.execute("SELECT s.target,s.status,s.provider,s.actor,s.created_at,u.email FROM searches s JOIN users u ON u.id=s.user_id ORDER BY s.created_at DESC LIMIT 500").fetchall()
    return render_template("admin.html", users=users, searches=searches)


@app.get("/health")
def health(): return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
