# TokIntel Web App

This repository now includes a browser-based interface in `app.py` that uses the original TokIntel Apify workflow.

## Run locally

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open <http://localhost:5000>.

## API key behavior

The app asks for an Apify API token before the first scan. The token is held server-side for the current browser session and is never placed in the HTML, returned by the API, or committed to Git. Clearing the key removes it from that session. A restart clears in-memory session keys, so each user must enter their own token again.

The required Apify actor is `clockworks/tiktok-profile-scraper`. The token owner is responsible for their Apify account and usage.

## Features

- Single or batch username scans (up to 25 per request)
- Username normalization with optional `@`
- Profile summary cards with metrics and profile links
- JSON report downloads in `reports/`
- Friendly handling of invalid tokens, API errors, empty results, and timeouts
- No debug mode enabled by default

Use only for lawful, authorized research and respect TikTok and Apify terms.
