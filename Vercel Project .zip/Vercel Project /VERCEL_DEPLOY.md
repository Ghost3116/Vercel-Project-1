# Vercel upload package

This project includes `api/index.py` and `vercel.json`, so it can be uploaded as a Python Flask project to Vercel.

## Upload

1. Create a new Vercel project.
2. Upload the project folder or import the ZIP contents.
3. In **Settings → Environment Variables**, add:

```text
FLASK_SECRET_KEY=<long random value>
APP_ENCRYPTION_KEY=<Fernet key>
ADMIN_EMAIL=<your admin email>
ADMIN_PASSWORD=<your admin password>
```

4. Redeploy.

Generate the encryption key with:

```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

## Important free-hosting limitation

Vercel serverless function filesystems are not durable. The included SQLite database will work for a demo, but accounts, encrypted API tokens, and admin audit logs can be lost when the function is replaced. For a real persistent site, use a hosted database and adapt `DATABASE_PATH`/the database layer, or deploy this same package to a Python host with persistent storage.

The app is therefore upload-ready for Vercel, but **no free host can safely provide durable per-email token storage from the uploaded files alone**. You still need to configure environment variables and a persistent database/storage service if the records must survive redeployments.

## Admin audit page

After signing in as the admin, open `/admin`. It shows:

- Registered email accounts
- Whether an encrypted Apify token is configured (never the token itself)
- Which email searched which TikTok username
- Provider: Apify
- Actor/API: `clockworks/tiktok-profile-scraper`
- Hit, miss, or error status
- Timestamp

Use HTTPS and never put API keys in source files, URLs, or screenshots.
